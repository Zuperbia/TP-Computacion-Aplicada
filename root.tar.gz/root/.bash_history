history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
passwd
hostnamectl set-hostname TPServer
nano /etc/hosts
cat /etc/hosts
loadkeys us
loadkeys us
dpkg-reconfigure keyboard-configuration
setupcon
cat /etc/hosts
which vi vim nano
vi /etc/hosts
cat /etc/hosts
cat etc/hostname
cat /etc/hostname
poweroff
hostname
cat /etc/os-release
ip a
ping -c 3 8.8.8.8
ping -c 3 deb.debian.org
ip route
cat /etc/resolv.conf
cat /etc/apt/sources.list
cat /etc/apt/sources.list
ls /etc/apt/sources.list.d/
apt update
ping -c 1 cdn2-fastly.deb.debian.org
cp /etc/apt/sources.list /etc/apt/sources.list.bak
vim /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt list --upgradable
apt upgrade
cp /etc/apt/sources.list /etc/apt/sources.list.bullseye
vim /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
df -h
apt full-upgrade
reboot
cat /etc/debian_version
cat /etc/ps-release
cat /etc/os-release
uname -r
apt autoremove
cp /etc/network/interfaces /etc/network/interfaces.bak
cat /etc/network/interfaces
ping -c 2 192.168.1.200
vim /etc/network/interfaces
cat /etc/network/interfaces
/etc/init.d/networking restart
ip a
ip route
ping -c 3 8.8.8.8
ping -c 3 deb.debian.org
shutdown -r now
ip a
ip route
ping -c 3 deb.debian.org
cat /etc/resolv.conf
poweroff
exit
ls /etc/ssh/
systemctl status ssh
grep -n PermitRootLogin /etc/ssh/sshd_config
apt install openssh-server
ls /etc/ssh/
grep -n PermitRootLogin /etc/ssh/sshd_config
systemctl status ssh
vim /etc/ssh/sshd_config
grep -n PermitRootLogin /etc/ssh/sshd_config
vim /etc/ssh/sshd_config
grep -n PermitRootLogin /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
shutdown
shutdown -c
shutdown -h now
exit
ls -l /root
chmod 600/root/clave_privada.txt
chmod 600 /root/clave_privada.txt
mkdir -p /root/.ssh
cat /root/clave_publica.pub >> /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
ls -l /root/clave_privada.txt
ter -tzf /root/Material_Adicional_TPVMCA.tar.gz
tar -tzf /root/Material_Adicional_TPVMCA.tar.gz
apt install apache2 php libapache2-mod-php
systemctl status apache2
php -v
cat /root/index.php
poweroff
cat /root/index.php
cp /root/index.php /root/logo.png /var/www/html/
rm /var/www/html/index.html
ls -l /var/www/html
cat /root/db.sql
apt-get install mariadb-server php-mysql
systemctl restart apache2
systemctl status mariadb
mariadb < /root/db.sql
mariadb -e "SHOW DATABASES;"
mariadb -e "SELECT * FROM ingenieria.alumnos;"
mariadb -e "SELECT user,host FROM mysql.user;"
lsblk
fdisk /dev/sdc
lsblk
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
mkdir /www_dir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
cp /etc/fstab /etc/fstab.bak
cat /etc/fstab
vim /etc/fstab
cat /etc/fstab
umount /www_dir /backup_dir
mount -a
df -h
systemctl daemon-reload
reboot
poweroff
df -h
cp -a /var/www/html/. /www_dir/
ls -l /www_dir
grep -n DocumentRoot /etc/apache2/sites-available/000-default.conf
vim /etc/apache2/sites-available/000-default.conf
apache2ctl configtest
systemctl restart apache2
rm /var/www/html/index.php /var/www/html/logo.png
cat /proc/partitions > /opt/particion
cat /opt/particion
df -h
grep -v '^\s*#' /etc/apache2/sites-available/000-default.conf
mkdir -p /opt/scripts
vim /opt/scripts/backup_full.sh
chmod 755 /opt/scripts/backup_full.sh
ls -l /opt/scripts
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /noexiste /backup_dir
/opt/scripts/backup_full.sh /var/log /backup_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
ls -l /backup_dir
umount /backup_dir
/opt/scripts/backup_full.sh /var/log /backup_dir
mount -a
df -h
systemctl status cron.service
crontab -e
crontab -l
crontab -e
ls -l /backup_dir
crontab -e
git --version
crontab -l
