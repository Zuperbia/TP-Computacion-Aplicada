#!/bin/bash
# backup_full.sh - Backup de un directorio en .tar.gz con fecha AAAAMMDD
# Uso: backup_full.sh ORIGEN DESTINO

ayuda () {
    echo "Uso: backup_full.sh ORIGEN DESTINO"
    echo "Ejemplo: backup_full.sh /var/log /backup_dir"
    echo "ORIGEN: directorio que se va a respaldar"
    echo "DESTINO: directorio donde se guarda el backup (debe estar montado)"
    echo "Opcion: -help muestra esta ayuda"
}

ORIGEN=$1
DESTINO=$2

if [[ "$1" == "-help" ]]; then
    ayuda
elif [[ $# -ne 2 ]]; then
    echo "Error: se necesitan 2 argumentos."
    ayuda
elif [[ ! -d "$ORIGEN" ]]; then
    echo "Error: el origen $ORIGEN no existe."
elif [[ ! -d "$DESTINO" ]]; then
    echo "Error: el destino $DESTINO no existe."
else
    MONTADO=$(mount | grep " $DESTINO ")
    if [[ -z "$MONTADO" ]]; then
        echo "Error: el destino $DESTINO no esta montado."
    else
        case $ORIGEN in
            /var/log) NOMBRE="log" ;;
            /www_dir) NOMBRE="www_dir" ;;
            *) NOMBRE="backup" ;;
        esac
        FECHA=$(date +%Y%m%d)
        ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"
        tar -czf "$ARCHIVO" "$ORIGEN"
        if [[ $? -eq 0 ]]; then
            echo "Backup creado: $ARCHIVO"
        else
            echo "Error al crear el backup."
        fi
    fi
fi
